DEMO ONLY. Synthetic byte-budget example: cat + newline + dog uses 7 bytes; bird does not fit.
Notebook cells are unexecuted. Diagram values are synthetic illustrations, not test logs.
